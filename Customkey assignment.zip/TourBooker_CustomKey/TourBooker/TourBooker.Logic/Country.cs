﻿namespace TourBooker.Logic
{
    public class Country
    {
        public string Name { get; }
        public CountryCode Code { get; }
        public string Region { get; }
        public int Population { get; }

        public Country(string name, string code, string region, int population)
        {
            Name = name;
            Code = new CountryCode(code);
            Region = region;
            Population = population;
        }

        public override string ToString() => $"{Name} ({Code})";
    }
}
