﻿using System;
using System.Threading.Tasks;

namespace ConcurrentCollections.SellShirts
{
    class Program
    {
        static void Main(string[] args)
        {
            StockController controller =
                new StockController(TShirtProvider.AllShirts);

            TimeSpan workDay = TimeSpan.FromMilliseconds(500);

            Task t1 = Task.Run(() => new SalesPerson("Kim").Work(workDay, controller));
            Task t2 = Task.Run(() => new SalesPerson("Alex").Work(workDay, controller));
            Task t3 = Task.Run(() => new SalesPerson("Sam").Work(workDay, controller));

            Task.WaitAll(t1, t2, t3);

            controller.DisplayStock();
        }
    }
}
