﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;

namespace ConcurrentCollections.SellShirts
{
    public class StockController
    {
        private ConcurrentDictionary<string, TShirt> _stock;

        public StockController(IEnumerable<TShirt> shirts)
        {
            _stock = new ConcurrentDictionary<string, TShirt>(
                shirts.ToDictionary(x => x.Code)
            );
        }

        public void Sell(string code)
        {
            _stock.TryRemove(code, out _);
        }

        public TShirt SelectRandomShirt()
        {
            
            var items = _stock.ToArray();
            if (items.Length == 0)
                return null; 

            Thread.Sleep(Rnd.NextInt(10));

            var selected = items[Rnd.NextInt(items.Length)];
            return selected.Value;
        }

        public void DisplayStock()
        {
            Console.WriteLine($"\r\n{_stock.Count} items left in stock:");
            foreach (TShirt shirt in _stock.Values)
                Console.WriteLine(shirt);
        }
    }
}
