﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;
using MilitaryApp.Domain.Entities;

namespace MilitaryApp.Data
{
    public class MilitaryContext : DbContext
    {
        public DbSet<Military> Militaries => Set<Military>();
        public DbSet<Quote> Quotes => Set<Quote>();
        public DbSet<King> Kings => Set<King>();

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            
            options.UseSqlServer(
    "Data Source=(local)\\SQLexpress;" +
    "Initial Catalog=MilitaryDB;" +
    "Integrated Security=True;" +
    "TrustServerCertificate=True");

        }
    }
}
