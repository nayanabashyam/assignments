﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryApp.Domain.Entities
{
    public class King
    {
        public int Id { get; set; }

        public string KingName { get; set; } = string.Empty;
    }
}
