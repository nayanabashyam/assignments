﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace MilitaryApp.Domain.Entities
{
    public class Military
    {
        public Military()
        {
            Quotes = new List<Quote>();
        }

        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public List<Quote> Quotes { get; set; }

        public King? King { get; set; }   
    }
}

