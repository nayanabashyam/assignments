﻿namespace MilitaryApp.Domain
{
    public class Class1
    {

    }
}
