﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<DateTime> dates = new List<DateTime>();

        DateTime start = DateTime.Today;
        DateTime end = start.AddYears(5);

        DateTime d = new DateTime(start.Year, start.Month, 13);
        while (d <= end)
        {
            dates.Add(d);
            d = d.AddMonths(1);
        }

        Console.WriteLine("Friday the 13th");
        Console.WriteLine("================\n");

        Console.WriteLine("1. Show all 13th dates");
        Console.WriteLine("2. Show Friday 13ths");
        Console.Write("\nEnter choice: ");
        string choice = Console.ReadLine();

        Console.WriteLine("\n------------------");

        foreach (DateTime date in dates)
        {
            if (choice == "1")
            {
                Console.WriteLine(date.ToString("dd MMMM yyyy"));
            }
            else if (choice == "2" && date.DayOfWeek == DayOfWeek.Friday)
            {
                Console.WriteLine(date.ToString("dd MMMM yyyy"));
            }
        }

        Console.ReadLine();
    }
}
